-- Procedimiento para insertar un nuevo veh�culo
CREATE PROCEDURE InsertarVehiculo
    @Marca NVARCHAR(255),
    @Entidad NVARCHAR(255),
    @Cilindraje NVARCHAR(50),
    @Verificacion NVARCHAR(50),
    @Placa NVARCHAR(50),
    @Motor NVARCHAR(50),
    @Modelo NVARCHAR(50),
    @Anio INT,
    @Serie NVARCHAR(50),
    @Seguro NVARCHAR(255),
    @Observaciones NVARCHAR(MAX),
    @ClienteCodigo INT
AS
BEGIN
    INSERT INTO Vehiculos (Marca, Entidad, Cilindraje, Verificacion, Placa, Motor, Modelo, Anio, Serie, Seguro, Observaciones, ClienteCodigo)
    VALUES (@Marca, @Entidad, @Cilindraje, @Verificacion, @Placa, @Motor, @Modelo, @Anio, @Serie, @Seguro, @Observaciones, @ClienteCodigo);
END;
GO

-- Procedimiento para actualizar un veh�culo existente
CREATE PROCEDURE ActualizarVehiculo
    @Id INT,
    @Marca NVARCHAR(255),
    @Entidad NVARCHAR(255),
    @Cilindraje NVARCHAR(50),
    @Verificacion NVARCHAR(50),
    @Placa NVARCHAR(50),
    @Motor NVARCHAR(50),
    @Modelo NVARCHAR(50),
    @Anio INT,
    @Serie NVARCHAR(50),
    @Seguro NVARCHAR(255),
    @Observaciones NVARCHAR(MAX),
    @ClienteCodigo INT
AS
BEGIN
    UPDATE Vehiculos
    SET Marca = @Marca, Entidad = @Entidad, Cilindraje = @Cilindraje, Verificacion = @Verificacion, Placa = @Placa,
        Motor = @Motor, Modelo = @Modelo, Anio = @Anio, Serie = @Serie, Seguro = @Seguro, Observaciones = @Observaciones,
        ClienteCodigo = @ClienteCodigo
    WHERE Id = @Id;
END;
GO

-- Procedimiento para eliminar un veh�culo por ID
CREATE PROCEDURE EliminarVehiculo
    @Id INT
AS
BEGIN
    DELETE FROM Vehiculos
    WHERE Id = @Id;
END;
GO

-- Procedimiento para buscar un veh�culo por ID
CREATE PROCEDURE BuscarVehiculoPorId
    @Id INT
AS
BEGIN
    SELECT *
    FROM Vehiculos
    WHERE Id = @Id;
END;
GO
