CREATE TABLE Usuarios (
    Id INT PRIMARY KEY IDENTITY(1,1),
    NombreUsuario NVARCHAR(50) NOT NULL,
    Contrase�a NVARCHAR(50) NOT NULL
);

INSERT INTO Usuarios (NombreUsuario, Contrase�a, EsAdministrador)
VALUES ('usuario_prueba', '12345', 1);


CREATE TABLE Clientes1 (
    codigoCliente INT PRIMARY KEY IDENTITY(1,1),
    nombreCompleto VARCHAR(255) NOT NULL,
    direccion VARCHAR(255),
    telefono VARCHAR(50),
    correoElectronico VARCHAR(200),
    fechaNacimiento DATE,
    numeroIdentificacion VARCHAR(100)
);



CREATE TABLE Vehiculo (
    codigoVehiculo INT PRIMARY KEY IDENTITY(1,1),
    marcaVehiculo VARCHAR(255) NOT NULL,
    cilindrajeVehiculo INT,
    verificacionVehiculo VARCHAR(50),
    placaVehiculo VARCHAR(20) UNIQUE,
    motorVehiculo VARCHAR(50),
    modeloVehiculo VARCHAR(50),
    anioVehiculo INT,
    serieVehiculo VARCHAR(50),
    seguroVehiculo VARCHAR(255),
    observacionesVehiculo TEXT,
    clienteCodigoVehiculo INT,
    FOREIGN KEY (clienteCodigoVehiculo) REFERENCES Clientes1(codigoCliente)
);


CREATE TABLE Mantenimiento (
    Id INT PRIMARY KEY IDENTITY,
    Codigo NVARCHAR(50) NOT NULL,
    Servicio NVARCHAR(100) NOT NULL,
    Responsable NVARCHAR(100) NOT NULL,
    Fecha DATE NOT NULL,
    Costo DECIMAL(10, 2) NOT NULL,
    TipoMantenimiento NVARCHAR(50) NOT NULL,
    Estado NVARCHAR(50) NOT NULL
);



CREATE TABLE DetalleMantenimiento (
    Id INT PRIMARY KEY,
    MantenimientoId INT NOT NULL,
    Concepto VARCHAR(100) NOT NULL,
    Costo DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (MantenimientoId) REFERENCES Mantenimiento(Id)
);

CREATE TABLE ProximoMantenimiento (
    Id INT PRIMARY KEY,
    MantenimientoId INT NOT NULL,
    FechaProximoMantenimiento DATE NOT NULL,
    Descripcion VARCHAR(200),
    FOREIGN KEY (MantenimientoId) REFERENCES Mantenimiento(Id)
);

