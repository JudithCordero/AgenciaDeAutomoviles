CREATE PROCEDURE SP_Login
    @NombreUsuario NVARCHAR(50),
    @Contrase�a NVARCHAR(50)
AS
BEGIN
    SELECT Id, NombreUsuario
    FROM Usuarios
    WHERE NombreUsuario = @NombreUsuario AND Contrase�a = @Contrase�a;
END;
