CREATE TABLE Usuarios (
    Id INT PRIMARY KEY IDENTITY(1,1),
    NombreUsuario NVARCHAR(255) NOT NULL,
    Contrase�a NVARCHAR(255) NOT NULL,
    EsAdministrador BIT NOT NULL DEFAULT 0
);

CREATE TABLE Clientes (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(255) NOT NULL,
    Telefono NVARCHAR(20),
    CorreoElectronico NVARCHAR(255),
    Direccion NVARCHAR(255)
);

CREATE TABLE Vehiculos (
    Id INT PRIMARY KEY IDENTITY(1,1),
    ClienteId INT NOT NULL,
    Marca NVARCHAR(255) NOT NULL,
    Modelo NVARCHAR(255) NOT NULL,
    Anio INT NOT NULL,
    FOREIGN KEY (ClienteId) REFERENCES Clientes(Id)
);

CREATE TABLE Mantenimientos (
    Id INT PRIMARY KEY IDENTITY(1,1),
    VehiculoId INT NOT NULL,
    Tipo NVARCHAR(255) NOT NULL,
    Fecha DATE NOT NULL,
    Estado NVARCHAR(20) NOT NULL DEFAULT 'En espera',
    Descripcion NVARCHAR(MAX),
    FOREIGN KEY (VehiculoId) REFERENCES Vehiculos(Id) ON DELETE CASCADE
);

CREATE TABLE Servicios (
    Id INT PRIMARY KEY IDENTITY(1,1),
    MantenimientoId INT NOT NULL,
    Descripcion NVARCHAR(MAX),
    FOREIGN KEY (MantenimientoId) REFERENCES Mantenimientos(Id) ON DELETE CASCADE
);

CREATE TABLE Refacciones (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(255) NOT NULL,
    Cantidad INT NOT NULL
);

CREATE TABLE ActividadesMantenimiento (
    Id INT PRIMARY KEY IDENTITY(1,1),
    MantenimientoId INT NOT NULL,
    RefaccionId INT NOT NULL,
    CantidadUtilizada INT NOT NULL,
    FOREIGN KEY (MantenimientoId) REFERENCES Mantenimientos(Id) ON DELETE CASCADE,
    FOREIGN KEY (RefaccionId) REFERENCES Refacciones(Id) ON DELETE CASCADE
);

CREATE TABLE Marcas (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(255) NOT NULL
);

CREATE TABLE Modelos (
    Id INT PRIMARY KEY IDENTITY(1,1),
    MarcaId INT NOT NULL,
    Nombre NVARCHAR(255) NOT NULL,
    Anio INT NOT NULL,
    FOREIGN KEY (MarcaId) REFERENCES Marcas(Id) ON DELETE CASCADE
);

CREATE TABLE HistorialMantenimientos (
    Id INT PRIMARY KEY IDENTITY(1,1),
    VehiculoId INT NOT NULL,
    MantenimientoId INT NOT NULL,
    Fecha DATE NOT NULL,
    Estado NVARCHAR(20) NOT NULL,
    FOREIGN KEY (VehiculoId) REFERENCES Vehiculos(Id) ON DELETE CASCADE,
    FOREIGN KEY (MantenimientoId) REFERENCES Mantenimientos(Id) ON DELETE CASCADE
);
