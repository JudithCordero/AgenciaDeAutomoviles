-- Procedimiento para insertar un nuevo cliente
CREATE PROCEDURE InsertarCliente
    @Codigo INT,
    @Nombre NVARCHAR(255),
    @Telefono NVARCHAR(20)
AS
BEGIN
    INSERT INTO Clientes (Codigo, Nombre, Telefono)
    VALUES (@Codigo, @Nombre, @Telefono);
END;
GO

-- Procedimiento para actualizar un cliente existente
CREATE PROCEDURE ActualizarCliente
    @Codigo INT,
    @Nombre NVARCHAR(255),
    @Telefono NVARCHAR(20)
AS
BEGIN
    UPDATE Clientes
    SET Nombre = @Nombre, Telefono = @Telefono
    WHERE Codigo = @Codigo;
END;
GO

-- Procedimiento para eliminar un cliente por c�digo
CREATE PROCEDURE EliminarCliente
    @Codigo INT
AS
BEGIN
    DELETE FROM Clientes
    WHERE Codigo = @Codigo;
END;
GO

-- Procedimiento para buscar un cliente por c�digo
CREATE PROCEDURE BuscarClientePorCodigo
    @Codigo INT
AS
BEGIN
    SELECT *
    FROM Clientes
    WHERE Codigo = @Codigo;
END;
GO
