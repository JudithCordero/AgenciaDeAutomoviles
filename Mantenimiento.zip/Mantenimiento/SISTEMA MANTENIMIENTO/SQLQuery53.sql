SELECT TOP (1000) [Id]
      ,[Codigo]
      ,[Servicio]
      ,[Responsable]
      ,[Fecha]
      ,[Costo]
      ,[TipoMantenimiento]
      ,[Estado]
  FROM [MiBaseDeDatos].[dbo].[Mantenimientos]


  TRUNCATE TABLE [MiBaseDeDatos].[dbo].[Mantenimientos]
