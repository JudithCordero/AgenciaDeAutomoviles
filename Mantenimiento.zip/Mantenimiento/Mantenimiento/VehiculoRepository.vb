﻿Imports System.Data.SqlClient

Public Class VehiculoRepository
    Private connectionString As String = "Data Source=ZULEMASAUCEDO\ZULEMA;Initial Catalog=MiBaseDeDatos;Integrated Security=True"

    Public Function AgregarVehiculo(vehiculo As Vehiculo) As Integer
        Dim query As String = "INSERT INTO Vehiculo (marcaVehiculo, cilindrajeVehiculo, verificacionVehiculo, placaVehiculo, motorVehiculo, modeloVehiculo, anioVehiculo, serieVehiculo, seguroVehiculo, observacionesVehiculo, clienteCodigoVehiculo) " &
                              "VALUES (@Marca, @Cilindraje, @Verificacion, @Placa, @Motor, @Modelo, @Anio, @Serie, @Seguro, @Observaciones, @ClienteCodigo); " &
                              "SELECT SCOPE_IDENTITY();"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Marca", vehiculo.MarcaVehiculo)
                command.Parameters.AddWithValue("@Cilindraje", vehiculo.CilindrajeVehiculo)
                command.Parameters.AddWithValue("@Verificacion", vehiculo.VerificacionVehiculo)
                command.Parameters.AddWithValue("@Placa", vehiculo.PlacaVehiculo)
                command.Parameters.AddWithValue("@Motor", vehiculo.MotorVehiculo)
                command.Parameters.AddWithValue("@Modelo", vehiculo.ModeloVehiculo)
                command.Parameters.AddWithValue("@Anio", vehiculo.AnioVehiculo)
                command.Parameters.AddWithValue("@Serie", vehiculo.SerieVehiculo)
                command.Parameters.AddWithValue("@Seguro", vehiculo.SeguroVehiculo)
                command.Parameters.AddWithValue("@Observaciones", vehiculo.ObservacionesVehiculo)
                command.Parameters.AddWithValue("@ClienteCodigo", vehiculo.ClienteCodigoVehiculo)

                connection.Open()
                Dim codigoVehiculo As Integer = Convert.ToInt32(command.ExecuteScalar())
                Return codigoVehiculo
            End Using
        End Using
    End Function

    Public Function ModificarVehiculo(vehiculo As Vehiculo) As Boolean
        Dim query As String = "UPDATE Vehiculo SET marcaVehiculo = @Marca, cilindrajeVehiculo = @Cilindraje, verificacionVehiculo = @Verificacion, " &
                              "placaVehiculo = @Placa, motorVehiculo = @Motor, modeloVehiculo = @Modelo, anioVehiculo = @Anio, " &
                              "serieVehiculo = @Serie, seguroVehiculo = @Seguro, observacionesVehiculo = @Observaciones, clienteCodigoVehiculo = @ClienteCodigo " &
                              "WHERE codigoVehiculo = @Codigo;"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Marca", vehiculo.MarcaVehiculo)
                command.Parameters.AddWithValue("@Cilindraje", vehiculo.CilindrajeVehiculo)
                command.Parameters.AddWithValue("@Verificacion", vehiculo.VerificacionVehiculo)
                command.Parameters.AddWithValue("@Placa", vehiculo.PlacaVehiculo)
                command.Parameters.AddWithValue("@Motor", vehiculo.MotorVehiculo)
                command.Parameters.AddWithValue("@Modelo", vehiculo.ModeloVehiculo)
                command.Parameters.AddWithValue("@Anio", vehiculo.AnioVehiculo)
                command.Parameters.AddWithValue("@Serie", vehiculo.SerieVehiculo)
                command.Parameters.AddWithValue("@Seguro", vehiculo.SeguroVehiculo)
                command.Parameters.AddWithValue("@Observaciones", vehiculo.ObservacionesVehiculo)
                command.Parameters.AddWithValue("@ClienteCodigo", vehiculo.ClienteCodigoVehiculo)
                command.Parameters.AddWithValue("@Codigo", vehiculo.CodigoVehiculo)

                connection.Open()
                Dim rowsAffected As Integer = command.ExecuteNonQuery()
                Return rowsAffected > 0
            End Using
        End Using
    End Function

    Public Function EliminarVehiculo(codigoVehiculo As Integer) As Boolean
        Dim query As String = "DELETE FROM Vehiculo WHERE codigoVehiculo = @Codigo;"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Codigo", codigoVehiculo)

                connection.Open()
                Dim rowsAffected As Integer = command.ExecuteNonQuery()
                Return rowsAffected > 0
            End Using
        End Using
    End Function

    Public Function BuscarVehiculoPorCodigo(codigoVehiculo As Integer) As Vehiculo
        Dim query As String = "SELECT * FROM Vehiculo WHERE codigoVehiculo = @Codigo;"
        Dim vehiculo As Vehiculo = Nothing

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Codigo", codigoVehiculo)

                connection.Open()
                Using reader As SqlDataReader = command.ExecuteReader()
                    If reader.Read() Then
                        vehiculo = New Vehiculo()
                        vehiculo.CodigoVehiculo = Convert.ToInt32(reader("codigoVehiculo"))
                        vehiculo.MarcaVehiculo = Convert.ToString(reader("marcaVehiculo"))
                        vehiculo.CilindrajeVehiculo = Convert.ToInt32(reader("cilindrajeVehiculo"))
                        vehiculo.VerificacionVehiculo = Convert.ToString(reader("verificacionVehiculo"))
                        vehiculo.PlacaVehiculo = Convert.ToString(reader("placaVehiculo"))
                        vehiculo.MotorVehiculo = Convert.ToString(reader("motorVehiculo"))
                        vehiculo.ModeloVehiculo = Convert.ToString(reader("modeloVehiculo"))
                        vehiculo.AnioVehiculo = Convert.ToInt32(reader("anioVehiculo"))
                        vehiculo.SerieVehiculo = Convert.ToString(reader("serieVehiculo"))
                        vehiculo.SeguroVehiculo = Convert.ToString(reader("seguroVehiculo"))
                        vehiculo.ObservacionesVehiculo = Convert.ToString(reader("observacionesVehiculo"))
                        vehiculo.ClienteCodigoVehiculo = Convert.ToInt32(reader("clienteCodigoVehiculo"))
                    End If
                End Using
            End Using
        End Using

        Return vehiculo
    End Function

    Public Function BuscarVehiculoPorPlaca(placa As String) As Vehiculo
        Dim query As String = "SELECT * FROM Vehiculo WHERE placaVehiculo = @Placa;"
        Dim vehiculo As Vehiculo = Nothing

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Placa", placa)

                connection.Open()
                Using reader As SqlDataReader = command.ExecuteReader()
                    If reader.Read() Then
                        vehiculo = New Vehiculo()
                        vehiculo.CodigoVehiculo = Convert.ToInt32(reader("codigoVehiculo"))
                        vehiculo.MarcaVehiculo = Convert.ToString(reader("marcaVehiculo"))
                        vehiculo.CilindrajeVehiculo = Convert.ToInt32(reader("cilindrajeVehiculo"))
                        vehiculo.VerificacionVehiculo = Convert.ToString(reader("verificacionVehiculo"))
                        vehiculo.PlacaVehiculo = Convert.ToString(reader("placaVehiculo"))
                        vehiculo.MotorVehiculo = Convert.ToString(reader("motorVehiculo"))
                        vehiculo.ModeloVehiculo = Convert.ToString(reader("modeloVehiculo"))
                        vehiculo.AnioVehiculo = Convert.ToInt32(reader("anioVehiculo"))
                        vehiculo.SerieVehiculo = Convert.ToString(reader("serieVehiculo"))
                        vehiculo.SeguroVehiculo = Convert.ToString(reader("seguroVehiculo"))
                        vehiculo.ObservacionesVehiculo = Convert.ToString(reader("observacionesVehiculo"))
                        vehiculo.ClienteCodigoVehiculo = Convert.ToInt32(reader("clienteCodigoVehiculo"))
                    End If
                End Using
            End Using
        End Using

        Return vehiculo
    End Function

    Public Function ObtenerTodosLosVehiculos() As List(Of Vehiculo)
        Dim query As String = "SELECT * FROM Vehiculo;"
        Dim vehiculos As New List(Of Vehiculo)()

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                connection.Open()
                Using reader As SqlDataReader = command.ExecuteReader()
                    While reader.Read()
                        Dim vehiculo As New Vehiculo()
                        vehiculo.CodigoVehiculo = Convert.ToInt32(reader("codigoVehiculo"))
                        vehiculo.MarcaVehiculo = Convert.ToString(reader("marcaVehiculo"))
                        vehiculo.CilindrajeVehiculo = Convert.ToInt32(reader("cilindrajeVehiculo"))
                        vehiculo.VerificacionVehiculo = Convert.ToString(reader("verificacionVehiculo"))
                        vehiculo.PlacaVehiculo = Convert.ToString(reader("placaVehiculo"))
                        vehiculo.MotorVehiculo = Convert.ToString(reader("motorVehiculo"))
                        vehiculo.ModeloVehiculo = Convert.ToString(reader("modeloVehiculo"))
                        vehiculo.AnioVehiculo = Convert.ToInt32(reader("anioVehiculo"))
                        vehiculo.SerieVehiculo = Convert.ToString(reader("serieVehiculo"))
                        vehiculo.SeguroVehiculo = Convert.ToString(reader("seguroVehiculo"))
                        vehiculo.ObservacionesVehiculo = Convert.ToString(reader("observacionesVehiculo"))
                        vehiculo.ClienteCodigoVehiculo = Convert.ToInt32(reader("clienteCodigoVehiculo"))

                        vehiculos.Add(vehiculo)
                    End While
                End Using
            End Using
        End Using

        Return vehiculos
    End Function
End Class
