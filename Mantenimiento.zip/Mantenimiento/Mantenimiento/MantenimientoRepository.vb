﻿Imports System.Data.SqlClient

Public Class MantenimientoRepository
    Private connectionString As String = "Data Source=ZULEMASAUCEDO\ZULEMA;Initial Catalog=MiBaseDeDatos;Integrated Security=True"

    Public Function AgregarMantenimiento(mantenimiento As Mantenimiento) As Integer
        Dim query As String = "INSERT INTO Mantenimientos (Codigo, Servicio, Responsable, Fecha, Costo, TipoMantenimiento, Estado) VALUES (@Codigo, @Servicio, @Responsable, @Fecha, @Costo, @TipoMantenimiento, @Estado); SELECT SCOPE_IDENTITY();"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Codigo", mantenimiento.Codigo)
                command.Parameters.AddWithValue("@Servicio", mantenimiento.Servicio)
                command.Parameters.AddWithValue("@Responsable", mantenimiento.Responsable)
                command.Parameters.AddWithValue("@Fecha", mantenimiento.Fecha)
                command.Parameters.AddWithValue("@Costo", mantenimiento.Costo)
                command.Parameters.AddWithValue("@TipoMantenimiento", mantenimiento.TipoMantenimiento)
                command.Parameters.AddWithValue("@Estado", mantenimiento.Estado)

                connection.Open()
                Dim id As Integer = Convert.ToInt32(command.ExecuteScalar())
                Return id
            End Using
        End Using
    End Function

    Public Function ActualizarMantenimiento(mantenimiento As Mantenimiento) As Boolean
        Dim query As String = "UPDATE Mantenimientos SET Codigo = @Codigo, Servicio = @Servicio, Responsable = @Responsable, Fecha = @Fecha, Costo = @Costo, TipoMantenimiento = @TipoMantenimiento, Estado = @Estado WHERE Id = @Id;"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Codigo", mantenimiento.Codigo)
                command.Parameters.AddWithValue("@Servicio", mantenimiento.Servicio)
                command.Parameters.AddWithValue("@Responsable", mantenimiento.Responsable)
                command.Parameters.AddWithValue("@Fecha", mantenimiento.Fecha)
                command.Parameters.AddWithValue("@Costo", mantenimiento.Costo)
                command.Parameters.AddWithValue("@TipoMantenimiento", mantenimiento.TipoMantenimiento)
                command.Parameters.AddWithValue("@Estado", mantenimiento.Estado)
                command.Parameters.AddWithValue("@Id", mantenimiento.Id)

                connection.Open()
                Dim rowsAffected As Integer = command.ExecuteNonQuery()
                Return rowsAffected > 0
            End Using
        End Using
    End Function

    Public Function EliminarMantenimiento(id As Integer) As Boolean
        Dim query As String = "DELETE FROM Mantenimientos WHERE Id = @Id;"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Id", id)

                connection.Open()
                Dim rowsAffected As Integer = command.ExecuteNonQuery()
                Return rowsAffected > 0
            End Using
        End Using
    End Function

    Public Function BuscarMantenimientoPorId(id As Integer) As Mantenimiento
        Dim query As String = "SELECT * FROM Mantenimientos WHERE Id = @Id;"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Id", id)

                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then
                    Dim mantenimiento As New Mantenimiento()
                    mantenimiento.Id = Convert.ToInt32(reader("Id"))
                    mantenimiento.Codigo = reader("Codigo").ToString()
                    mantenimiento.Servicio = reader("Servicio").ToString()
                    mantenimiento.Responsable = reader("Responsable").ToString()
                    mantenimiento.Fecha = Convert.ToDateTime(reader("Fecha"))
                    mantenimiento.Costo = Convert.ToDecimal(reader("Costo"))
                    mantenimiento.TipoMantenimiento = reader("TipoMantenimiento").ToString()
                    mantenimiento.Estado = reader("Estado").ToString()
                    Return mantenimiento
                End If
            End Using
        End Using

        Return Nothing
    End Function

    Public Function ObtenerKilometrajeActual() As Integer
        Return 50000
    End Function

    Public Function CalcularProximoMantenimiento(kilometrajeActual As Integer) As Date
        Dim kilometrajeProximoMantenimiento As Integer = kilometrajeActual + 10000
        Dim fechaProximoMantenimiento As Date = Date.Today.AddDays(30)
        Return fechaProximoMantenimiento
    End Function
End Class
