﻿Imports System.Data.SqlClient

Public Class ClienteRepository
    Private connectionString As String = "Data Source=ZULEMASAUCEDO\ZULEMA;Initial Catalog=MiBaseDeDatos;Integrated Security=True"

    Public Function AgregarCliente(cliente As Cliente) As Integer
        Dim query As String = "INSERT INTO Clientes1 (NombreCompleto, Direccion, Telefono, CorreoElectronico, FechaNacimiento) " &
                              "VALUES (@NombreCompleto, @Direccion, @Telefono, @CorreoElectronico, @FechaNacimiento); " &
                              "SELECT SCOPE_IDENTITY();"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@NombreCompleto", cliente.NombreCompleto)
                command.Parameters.AddWithValue("@Direccion", cliente.Direccion)
                command.Parameters.AddWithValue("@Telefono", cliente.Telefono)
                command.Parameters.AddWithValue("@CorreoElectronico", cliente.CorreoElectronico)
                command.Parameters.AddWithValue("@FechaNacimiento", cliente.FechaNacimiento)

                connection.Open()
                Dim codigoCliente As Integer = Convert.ToInt32(command.ExecuteScalar())
                Return codigoCliente
            End Using
        End Using
    End Function

    Public Sub ModificarCliente(cliente As Cliente)
        Dim query As String = "UPDATE Clientes1 SET NombreCompleto = @NombreCompleto, " &
                              "Direccion = @Direccion, Telefono = @Telefono, " &
                              "CorreoElectronico = @CorreoElectronico, FechaNacimiento = @FechaNacimiento " &
                              "WHERE codigoCliente = @Codigo;"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@NombreCompleto", cliente.NombreCompleto)
                command.Parameters.AddWithValue("@Direccion", cliente.Direccion)
                command.Parameters.AddWithValue("@Telefono", cliente.Telefono)
                command.Parameters.AddWithValue("@CorreoElectronico", cliente.CorreoElectronico)
                command.Parameters.AddWithValue("@FechaNacimiento", cliente.FechaNacimiento)
                command.Parameters.AddWithValue("@Codigo", cliente.Codigo)

                connection.Open()
                command.ExecuteNonQuery()
            End Using
        End Using
    End Sub

    Public Sub EliminarCliente(codigoCliente As Integer)
        Dim query As String = "DELETE FROM Clientes1 WHERE codigoCliente = @Codigo;"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Codigo", codigoCliente)

                connection.Open()
                command.ExecuteNonQuery()
            End Using
        End Using
    End Sub

    Public Function BuscarClientePorCodigo(codigoCliente As Integer) As Cliente
        Dim query As String = "SELECT * FROM Clientes1 WHERE codigoCliente = @Codigo;"
        Dim cliente As Cliente = Nothing

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Codigo", codigoCliente)

                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then
                    cliente = New Cliente()
                    cliente.Codigo = Convert.ToInt32(reader("codigoCliente"))
                    cliente.NombreCompleto = Convert.ToString(reader("NombreCompleto"))
                    cliente.Direccion = Convert.ToString(reader("Direccion"))
                    cliente.Telefono = Convert.ToString(reader("Telefono"))
                    cliente.CorreoElectronico = Convert.ToString(reader("CorreoElectronico"))
                    cliente.FechaNacimiento = Convert.ToDateTime(reader("FechaNacimiento"))
                End If

                reader.Close()
            End Using
        End Using

        Return cliente
    End Function

    Public Function ObtenerTodosLosClientes() As List(Of Cliente)
        Dim query As String = "SELECT * FROM Clientes1;"
        Dim clientes As New List(Of Cliente)()

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader()

                While reader.Read()
                    Dim cliente As New Cliente()
                    cliente.Codigo = Convert.ToInt32(reader("codigoCliente"))
                    cliente.NombreCompleto = Convert.ToString(reader("NombreCompleto"))
                    cliente.Direccion = Convert.ToString(reader("Direccion"))
                    cliente.Telefono = Convert.ToString(reader("Telefono"))
                    cliente.CorreoElectronico = Convert.ToString(reader("CorreoElectronico"))
                    cliente.FechaNacimiento = Convert.ToDateTime(reader("FechaNacimiento"))

                    clientes.Add(cliente)
                End While

                reader.Close()
            End Using
        End Using

        Return clientes
    End Function
End Class
