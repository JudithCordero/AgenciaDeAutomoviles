﻿Public Class Form3
    Private vehiculoRepository As New VehiculoRepository()
    Private clienteRepository As New ClienteRepository()
    Private codigoVehiculo As Integer

    Private Sub btnSiguiente_Click(sender As Object, e As EventArgs) Handles btnSiguiente.Click
        Dim form4 As New Form4()
        form4.Show()
        Me.Hide()
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Configurar la apariencia inicial del formulario
        LimpiarControles()
        CargarClientes()
    End Sub

    Private Sub LimpiarControles()
        ' Limpiar los valores de los controles del vehículo
        txtMarcaVehiculo.Clear()
        txtCilindrajeVehiculo.Clear()
        txtVerificacionVehiculo.Clear()
        txtPlacaVehiculo.Clear()
        txtMotorVehiculo.Clear()
        txtModeloVehiculo.Clear()
        txtAnioVehiculo.Clear()
        txtSerieVehiculo.Clear()
        txtSeguroVehiculo.Clear()
        txtObservacionesVehiculo.Clear()
        cmbClientes.SelectedIndex = -1
    End Sub

    Private Sub CargarClientes()
        ' Cargar la lista de clientes en el ComboBox
        Try
            Dim clientes As List(Of Cliente) = clienteRepository.ObtenerTodosLosClientes()
            cmbClientes.DisplayMember = "NombreCompleto"
            cmbClientes.ValueMember = "Codigo"
            cmbClientes.DataSource = clientes
        Catch ex As Exception
            MessageBox.Show($"Error al cargar clientes: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub AgregarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarVehiculoToolStripMenuItem1.Click
        ' Validar que los campos obligatorios no estén vacíos
        If String.IsNullOrWhiteSpace(txtMarcaVehiculo.Text) OrElse String.IsNullOrWhiteSpace(txtPlacaVehiculo.Text) Then
            MessageBox.Show("Por favor, complete los campos obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Validar que se haya seleccionado un cliente
        If cmbClientes.SelectedItem Is Nothing Then
            MessageBox.Show("Por favor, seleccione un cliente para asociar el vehículo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Obtener el cliente seleccionado
        Dim clienteSeleccionado As Cliente = DirectCast(cmbClientes.SelectedItem, Cliente)

        ' Crear un nuevo vehículo con los datos ingresados
        Dim nuevoVehiculo As New Vehiculo()
        nuevoVehiculo.MarcaVehiculo = txtMarcaVehiculo.Text
        nuevoVehiculo.CilindrajeVehiculo = Convert.ToInt32(txtCilindrajeVehiculo.Text)
        nuevoVehiculo.VerificacionVehiculo = txtVerificacionVehiculo.Text
        nuevoVehiculo.PlacaVehiculo = txtPlacaVehiculo.Text
        nuevoVehiculo.MotorVehiculo = txtMotorVehiculo.Text
        nuevoVehiculo.ModeloVehiculo = txtModeloVehiculo.Text
        nuevoVehiculo.AnioVehiculo = Convert.ToInt32(txtAnioVehiculo.Text)
        nuevoVehiculo.SerieVehiculo = txtSerieVehiculo.Text
        nuevoVehiculo.SeguroVehiculo = txtSeguroVehiculo.Text
        nuevoVehiculo.ObservacionesVehiculo = txtObservacionesVehiculo.Text
        nuevoVehiculo.ClienteCodigoVehiculo = clienteSeleccionado.Codigo  ' Asignar el código del cliente seleccionado

        ' Agregar el nuevo vehículo a la base de datos a través del VehiculoRepository
        Try
            Dim codigoVehiculo As Integer = vehiculoRepository.AgregarVehiculo(nuevoVehiculo)

            ' Limpiar los controles después de agregar el vehículo
            LimpiarControles()

            ' Mostrar mensaje de éxito
            MessageBox.Show("Vehículo agregado correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show($"Error al agregar vehículo: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        End
    End Sub

    Private Sub btnRegresar_Click(sender As Object, e As EventArgs) Handles btnRegresar.Click
        Dim form2 As Form2 = Application.OpenForms.OfType(Of Form2)().FirstOrDefault()
        If form2 IsNot Nothing Then
            form2.Show()
            Me.Close()
        End If
    End Sub


    Private Sub BuscarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BuscarVehiculoToolStripMenuItem1.Click
        ' Pedir al usuario que ingrese el código del vehículo a buscar
        Dim codigoStr As String = InputBox("Ingrese el código del vehículo:", "Buscar Vehículo por Código")

        ' Verificar si se ingresó un código válido
        If Not String.IsNullOrWhiteSpace(codigoStr) AndAlso Integer.TryParse(codigoStr, codigoVehiculo) Then
            ' Crear una instancia del repositorio de vehículos
            Dim repository As New VehiculoRepository()

            ' Convertir el código a entero y realizar la búsqueda
            Dim vehiculo As Vehiculo = repository.BuscarVehiculoPorCodigo(codigoVehiculo)

            ' Verificar si se encontró el vehículo
            If vehiculo IsNot Nothing Then
                ' Mostrar los detalles del vehículo encontrado
                MessageBox.Show($"Vehículo encontrado: Código {vehiculo.codigoVehiculo}, Marca {vehiculo.MarcaVehiculo}", "Búsqueda Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ' Rellenar los campos del formulario con los datos del vehículo encontrado
                txtMarcaVehiculo.Text = vehiculo.MarcaVehiculo
                txtCilindrajeVehiculo.Text = vehiculo.CilindrajeVehiculo.ToString()
                txtVerificacionVehiculo.Text = vehiculo.VerificacionVehiculo
                txtPlacaVehiculo.Text = vehiculo.PlacaVehiculo
                txtMotorVehiculo.Text = vehiculo.MotorVehiculo
                txtModeloVehiculo.Text = vehiculo.ModeloVehiculo
                txtAnioVehiculo.Text = vehiculo.AnioVehiculo.ToString()
                txtSerieVehiculo.Text = vehiculo.SerieVehiculo
                txtSeguroVehiculo.Text = vehiculo.SeguroVehiculo
                txtObservacionesVehiculo.Text = vehiculo.ObservacionesVehiculo

                ' Seleccionar el cliente asociado al vehículo en el ComboBox
                For Each item As Cliente In cmbClientes.Items
                    If item.Codigo = vehiculo.ClienteCodigoVehiculo Then
                        cmbClientes.SelectedItem = item
                        Exit For
                    End If
                Next
            Else
                MessageBox.Show("No se encontró ningún vehículo con el código especificado.", "Búsqueda Fallida", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Else
            ' Mostrar mensaje de error si no se ingresó un código válido
            MessageBox.Show("Por favor, ingrese un código de vehículo válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub


    Private Sub ActualizarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ActualizarVehiculoToolStripMenuItem1.Click
        ' Validar que se haya seleccionado un vehículo para actualizar
        If codigoVehiculo <= 0 Then
            MessageBox.Show("Por favor, primero busque y seleccione un vehículo para actualizar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Validar que los campos obligatorios no estén vacíos
        If String.IsNullOrWhiteSpace(txtMarcaVehiculo.Text) OrElse String.IsNullOrWhiteSpace(txtPlacaVehiculo.Text) Then
            MessageBox.Show("Por favor, complete los campos obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Obtener el cliente seleccionado
        Dim clienteSeleccionado As Cliente = DirectCast(cmbClientes.SelectedItem, Cliente)

        ' Crear un objeto Vehiculo con los datos actualizados
        Dim vehiculoActualizado As New Vehiculo()
        vehiculoActualizado.codigoVehiculo = codigoVehiculo
        vehiculoActualizado.MarcaVehiculo = txtMarcaVehiculo.Text
        vehiculoActualizado.CilindrajeVehiculo = Convert.ToInt32(txtCilindrajeVehiculo.Text)
        vehiculoActualizado.VerificacionVehiculo = txtVerificacionVehiculo.Text
        vehiculoActualizado.PlacaVehiculo = txtPlacaVehiculo.Text
        vehiculoActualizado.MotorVehiculo = txtMotorVehiculo.Text
        vehiculoActualizado.ModeloVehiculo = txtModeloVehiculo.Text
        vehiculoActualizado.AnioVehiculo = Convert.ToInt32(txtAnioVehiculo.Text)
        vehiculoActualizado.SerieVehiculo = txtSerieVehiculo.Text
        vehiculoActualizado.SeguroVehiculo = txtSeguroVehiculo.Text
        vehiculoActualizado.ObservacionesVehiculo = txtObservacionesVehiculo.Text
        vehiculoActualizado.ClienteCodigoVehiculo = clienteSeleccionado.Codigo

        ' Actualizar el vehículo en la base de datos
        Try
            Dim exito As Boolean = vehiculoRepository.ModificarVehiculo(vehiculoActualizado)

            If exito Then
                LimpiarControles()
                MessageBox.Show("Vehículo actualizado correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("No se pudo actualizar el vehículo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show($"Error al actualizar vehículo: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub EliminarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EliminarVehiculoToolStripMenuItem1.Click
        ' Validar que se haya seleccionado un vehículo para eliminar
        If codigoVehiculo <= 0 Then
            MessageBox.Show("Por favor, primero busque y seleccione un vehículo para eliminar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Confirmar la eliminación con el usuario
        Dim confirmacion As DialogResult = MessageBox.Show("¿Está seguro de que desea eliminar este vehículo?", "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If confirmacion = DialogResult.Yes Then
            ' Eliminar el vehículo de la base de datos
            Try
                Dim exito As Boolean = vehiculoRepository.EliminarVehiculo(codigoVehiculo)

                If exito Then
                    LimpiarControles()
                    MessageBox.Show("Vehículo eliminado correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show("No se pudo eliminar el vehículo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

            Catch ex As Exception
                MessageBox.Show($"Error al eliminar vehículo: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

End Class
