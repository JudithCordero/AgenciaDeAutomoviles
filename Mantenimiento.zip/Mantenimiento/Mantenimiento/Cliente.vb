﻿Public Class Cliente
    Public Property Codigo As Integer
    Public Property CodigoCliente As Integer
    Public Property NombreCompleto As String
    Public Property Direccion As String
    Public Property Telefono As String
    Public Property CorreoElectronico As String
    Public Property FechaNacimiento As Date
    Public Property NumeroIdentificacion As String
End Class
