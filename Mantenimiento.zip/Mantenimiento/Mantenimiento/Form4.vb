﻿Imports System.Windows.Forms

Public Class Form4
    Private mantenimientoRepository As New MantenimientoRepository()

    Private Sub LimpiarControles()
        txtCodigo.Clear()
        txtServicio.Clear()
        txtResponsable.Clear()
        dtpFecha.Value = Date.Today
        txtcosto.Clear()
        cmbTipoMantenimiento.SelectedIndex = -1
        cmbEstado.SelectedIndex = -1
    End Sub

    Private Sub AgregarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarToolStripMenuItem1.Click
        AgregarMantenimiento()
    End Sub

    Private Sub ActualizarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ActualizarToolStripMenuItem1.Click
        ActualizarMantenimiento()
    End Sub

    Private Sub EliminarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EliminarToolStripMenuItem1.Click
        EliminarMantenimiento()
    End Sub

    Private Sub BuscarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BuscarToolStripMenuItem1.Click
        BuscarMantenimiento()
    End Sub

    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        Try
            Dim mantenimiento As Mantenimiento = ObtenerMantenimientoMostrado()

            ' Obtener la fecha estimada del próximo mantenimiento
            Dim kilometrajeActual As Integer = ObtenerKilometrajeActual()
            Dim fechaProximoMantenimiento As Date = CalcularProximoMantenimiento(kilometrajeActual)

            Dim desglose As String = $"Detalles del Mantenimiento:" & vbCrLf &
            $"ID: {mantenimiento.Id}" & vbCrLf &
            $"Código: {mantenimiento.Codigo}" & vbCrLf &
            $"Servicio: {mantenimiento.Servicio}" & vbCrLf &
            $"Responsable: {mantenimiento.Responsable}" & vbCrLf &
            $"Fecha: {mantenimiento.Fecha}" & vbCrLf &
            $"Costo: {mantenimiento.Costo}" & vbCrLf &
            $"Tipo de Mantenimiento: {mantenimiento.TipoMantenimiento}" & vbCrLf &
            $"Estado: {mantenimiento.Estado}" & vbCrLf &
            $"Próximo Mantenimiento: {fechaProximoMantenimiento.ToString("dd/MM/yyyy")}" ' Formato de fecha según necesites

            MessageBox.Show(desglose, "Desglose de Información del Mantenimiento", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show($"Error al obtener el desglose del mantenimiento: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function ObtenerMantenimientoMostrado() As Mantenimiento
        Dim idMantenimientoMostrado As Integer = ObtenerIdMantenimientoMostradoDesdeAlgunaFuente()

        If idMantenimientoMostrado > 0 Then
            Dim mantenimiento As Mantenimiento = mantenimientoRepository.BuscarMantenimientoPorId(idMantenimientoMostrado)
            If mantenimiento IsNot Nothing Then
                Return mantenimiento
            Else
                Throw New Exception("No se encontró ningún mantenimiento con el ID especificado.")
            End If
        Else
            Throw New Exception("ID de mantenimiento mostrado no válido.")
        End If
    End Function

    Private Function ObtenerIdMantenimientoMostradoDesdeAlgunaFuente() As Integer
        Dim idMantenimientoMostrado As Integer = 0

        If Integer.TryParse(txtCodigo.Text, idMantenimientoMostrado) Then
            Return idMantenimientoMostrado
        Else
            Return 0 ' Manejar el caso en el que el ID no es válido
        End If
    End Function

    Private Function ObtenerKilometrajeActual() As Integer
        ' Implementa lógica para obtener el kilometraje actual del vehículo
        ' Por ejemplo:
        ' Return mantenimientoRepository.ObtenerKilometrajeActual()
        Return 50000 ' Ejemplo: retorna un valor fijo para propósitos de demostración
    End Function

    Private Function CalcularProximoMantenimiento(kilometrajeActual As Integer) As Date
        ' Implementa lógica para calcular la fecha del próximo mantenimiento
        ' Por ejemplo:
        ' Return mantenimientoRepository.CalcularProximoMantenimiento(kilometrajeActual)
        Return Date.Today.AddDays(30) ' Ejemplo: se agrega 30 días desde la fecha actual
    End Function

    Private Sub AgregarMantenimiento()
        If ValidarCampos() Then
            Dim nuevoMantenimiento As New Mantenimiento()
            nuevoMantenimiento.Codigo = txtCodigo.Text  ' Utiliza txtCodigo como el código de vehículo
            nuevoMantenimiento.Servicio = txtServicio.Text
            nuevoMantenimiento.Responsable = txtResponsable.Text
            nuevoMantenimiento.Fecha = dtpFecha.Value
            nuevoMantenimiento.Costo = Convert.ToDecimal(txtcosto.Text)
            nuevoMantenimiento.TipoMantenimiento = cmbTipoMantenimiento.SelectedItem.ToString()
            nuevoMantenimiento.Estado = cmbEstado.SelectedItem.ToString()

            Try
                Dim id As Integer = mantenimientoRepository.AgregarMantenimiento(nuevoMantenimiento)
                LimpiarControles()
                MessageBox.Show("Mantenimiento agregado correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MessageBox.Show($"Error al agregar mantenimiento: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Else
            MessageBox.Show("Por favor, complete todos los campos obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Function ValidarCampos() As Boolean
        Return Not String.IsNullOrWhiteSpace(txtCodigo.Text) AndAlso
               Not String.IsNullOrWhiteSpace(txtServicio.Text) AndAlso
               Not String.IsNullOrWhiteSpace(txtResponsable.Text) AndAlso
               Not String.IsNullOrWhiteSpace(txtcosto.Text) AndAlso
               cmbTipoMantenimiento.SelectedIndex <> -1 AndAlso
               cmbEstado.SelectedIndex <> -1
    End Function

    Private Sub ActualizarMantenimiento()
        Dim codigoVehiculo As Integer
        If Integer.TryParse(txtCodigo.Text, codigoVehiculo) Then
            Dim mantenimiento As Mantenimiento = mantenimientoRepository.BuscarMantenimientoPorId(codigoVehiculo)
            If mantenimiento IsNot Nothing Then
                mantenimiento.Servicio = txtServicio.Text
                mantenimiento.Responsable = txtResponsable.Text
                mantenimiento.Fecha = dtpFecha.Value
                mantenimiento.Costo = Convert.ToDecimal(txtcosto.Text)
                mantenimiento.TipoMantenimiento = cmbTipoMantenimiento.SelectedItem.ToString()
                mantenimiento.Estado = cmbEstado.SelectedItem.ToString()

                Try
                    Dim updated As Boolean = mantenimientoRepository.ActualizarMantenimiento(mantenimiento)
                    If updated Then
                        MessageBox.Show("Mantenimiento actualizado correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        MessageBox.Show("No se pudo actualizar el mantenimiento.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Catch ex As Exception
                    MessageBox.Show($"Error al actualizar mantenimiento: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            Else
                MessageBox.Show("No se encontró ningún mantenimiento con el código de vehículo especificado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Else
            MessageBox.Show("Ingrese un código de vehículo válido para actualizar el mantenimiento.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub EliminarMantenimiento()
        Dim id As Integer
        If Integer.TryParse(txtCodigo.Text, id) Then
            Dim confirmResult As DialogResult = MessageBox.Show("¿Está seguro que desea eliminar este mantenimiento?", "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If confirmResult = DialogResult.Yes Then
                Try
                    Dim deleted As Boolean = mantenimientoRepository.EliminarMantenimiento(id)
                    If deleted Then
                        MessageBox.Show("Mantenimiento eliminado correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        LimpiarControles()
                    Else
                        MessageBox.Show("No se pudo eliminar el mantenimiento.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Catch ex As Exception
                    MessageBox.Show($"Error al eliminar mantenimiento: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If
        Else
            MessageBox.Show("Ingrese un ID de mantenimiento válido para eliminar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub BuscarMantenimiento()
        Dim codigoVehiculo As Integer
        If Integer.TryParse(txtCodigo.Text, codigoVehiculo) Then
            Dim mantenimiento As Mantenimiento = mantenimientoRepository.BuscarMantenimientoPorId(codigoVehiculo)
            If mantenimiento IsNot Nothing Then
                txtServicio.Text = mantenimiento.Servicio
                txtResponsable.Text = mantenimiento.Responsable
                dtpFecha.Value = mantenimiento.Fecha
                txtcosto.Text = mantenimiento.Costo.ToString()
                cmbTipoMantenimiento.SelectedItem = mantenimiento.TipoMantenimiento
                cmbEstado.SelectedItem = mantenimiento.Estado
            Else
                MessageBox.Show("No se encontró ningún mantenimiento con el código de vehículo especificado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Else
            MessageBox.Show("Ingrese un código de vehículo válido para buscar el mantenimiento.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        End
    End Sub

    Private Sub btnRegresar_Click(sender As Object, e As EventArgs) Handles btnRegresar.Click
        Me.Close()
    End Sub
End Class
