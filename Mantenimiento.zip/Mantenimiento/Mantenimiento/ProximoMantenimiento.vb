﻿Public Class ProximoMantenimiento
    Public Property Id As Integer
    Public Property MantenimientoId As Integer
    Public Property FechaProximoMantenimiento As DateTime
    Public Property Descripcion As String
End Class
