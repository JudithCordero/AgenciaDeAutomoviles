﻿Public Class Vehiculo
    Public codigoVehiculo As Integer
    Public Property MarcaVehiculo As String
    Public Property CilindrajeVehiculo As Integer
    Public Property VerificacionVehiculo As String
    Public Property PlacaVehiculo As String
    Public Property MotorVehiculo As String
    Public Property ModeloVehiculo As String
    Public Property AnioVehiculo As Integer
    Public Property SerieVehiculo As String
    Public Property SeguroVehiculo As String
    Public Property ObservacionesVehiculo As String
    Public Property ClienteCodigoVehiculo As Integer

    ' Constructor vacío necesario para serialización y ORMs
    Public Sub New()
    End Sub

    ' Constructor con parámetros para inicializar propiedades
    Public Sub New(marca As String, cilindraje As Integer, verificacion As String, placa As String, motor As String, modelo As String, anio As Integer, serie As String, seguro As String, observaciones As String, clienteCodigo As Integer)
        Me.MarcaVehiculo = marca
        Me.CilindrajeVehiculo = cilindraje
        Me.VerificacionVehiculo = verificacion
        Me.PlacaVehiculo = placa
        Me.MotorVehiculo = motor
        Me.ModeloVehiculo = modelo
        Me.AnioVehiculo = anio
        Me.SerieVehiculo = serie
        Me.SeguroVehiculo = seguro
        Me.ObservacionesVehiculo = observaciones
        Me.ClienteCodigoVehiculo = clienteCodigo
    End Sub
End Class
