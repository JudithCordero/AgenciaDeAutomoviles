﻿Public Class Mantenimiento
    Public Property Id As Integer
    Public Property Codigo As String
    Public Property Servicio As String
    Public Property Responsable As String
    Public Property Fecha As Date
    Public Property Costo As Decimal
    Public Property TipoMantenimiento As String
    Public Property Estado As String
End Class
