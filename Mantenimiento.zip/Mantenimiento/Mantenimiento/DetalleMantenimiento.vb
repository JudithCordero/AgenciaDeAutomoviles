﻿Public Class DetalleMantenimiento
    Public Property Id As Integer
    Public Property MantenimientoId As Integer
    Public Property Concepto As String
    Public Property Costo As Decimal
End Class
