﻿Imports System.Data.SqlClient
Public Class ConexionBD
    Private Shared connectionString As String = "Data Source=ZULEMASAUCEDO\ZULEMA;Initial Catalog=MiBaseDeDatos;Integrated Security=True"

    Public Shared Function Login(nombreUsuario As String, contraseña As String) As DataTable
        Dim dt As New DataTable()
        Using con As New SqlConnection(connectionString)
            con.Open()
            Using cmd As New SqlCommand("SP_Login", con)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@NombreUsuario", nombreUsuario)
                cmd.Parameters.AddWithValue("@Contraseña", contraseña)
                Dim adapter As New SqlDataAdapter(cmd)
                adapter.Fill(dt)
            End Using
        End Using
        Return dt
    End Function
End Class
