﻿Public Class Form1
    Private Sub btnIniciarSesion_Click(sender As Object, e As EventArgs) Handles btnIniciarSesion.Click
        Dim nombreUsuario As String = txtUsuario.Text
        Dim contraseña As String = txtContraseña.Text

        Dim dt As DataTable = ConexionBD.Login(nombreUsuario, contraseña)

        If dt.Rows.Count > 0 Then
            MessageBox.Show("Inicio de sesión exitoso.", "Inicio de Sesión", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Dim principalForm As New Form2()
            principalForm.Show()
            Me.Hide()
        Else
            MessageBox.Show("Credenciales incorrectas. Inténtelo de nuevo.", "Inicio de Sesión Fallido", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtContraseña.UseSystemPasswordChar = True
    End Sub
End Class
