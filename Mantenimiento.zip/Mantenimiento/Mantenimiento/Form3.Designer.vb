﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtObservacionesVehiculo = New System.Windows.Forms.TextBox()
        Me.txtSeguroVehiculo = New System.Windows.Forms.TextBox()
        Me.txtSerieVehiculo = New System.Windows.Forms.TextBox()
        Me.txtAnioVehiculo = New System.Windows.Forms.TextBox()
        Me.txtModeloVehiculo = New System.Windows.Forms.TextBox()
        Me.txtMotorVehiculo = New System.Windows.Forms.TextBox()
        Me.txtPlacaVehiculo = New System.Windows.Forms.TextBox()
        Me.txtVerificacionVehiculo = New System.Windows.Forms.TextBox()
        Me.txtCilindrajeVehiculo = New System.Windows.Forms.TextBox()
        Me.txtEntidadVehiculo = New System.Windows.Forms.TextBox()
        Me.txtMarcaVehiculo = New System.Windows.Forms.TextBox()
        Me.txtCodigoVehiculo = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AgregarVehiculoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActualizarVehiculoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EliminarVehiculoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BuscarVehiculoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnSiguiente = New System.Windows.Forms.Button()
        Me.btnCancelar = New System.Windows.Forms.Button()
        Me.btnRegresar = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbClientes = New System.Windows.Forms.ComboBox()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox1.Controls.Add(Me.cmbClientes)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtObservacionesVehiculo)
        Me.GroupBox1.Controls.Add(Me.txtSeguroVehiculo)
        Me.GroupBox1.Controls.Add(Me.txtSerieVehiculo)
        Me.GroupBox1.Controls.Add(Me.txtAnioVehiculo)
        Me.GroupBox1.Controls.Add(Me.txtModeloVehiculo)
        Me.GroupBox1.Controls.Add(Me.txtMotorVehiculo)
        Me.GroupBox1.Controls.Add(Me.txtPlacaVehiculo)
        Me.GroupBox1.Controls.Add(Me.txtVerificacionVehiculo)
        Me.GroupBox1.Controls.Add(Me.txtCilindrajeVehiculo)
        Me.GroupBox1.Controls.Add(Me.txtEntidadVehiculo)
        Me.GroupBox1.Controls.Add(Me.txtMarcaVehiculo)
        Me.GroupBox1.Controls.Add(Me.txtCodigoVehiculo)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Font = New System.Drawing.Font("Berlin Sans FB Demi", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(24, 29)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(908, 522)
        Me.GroupBox1.TabIndex = 31
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "+ Agregar Vehículo"
        '
        'txtObservacionesVehiculo
        '
        Me.txtObservacionesVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtObservacionesVehiculo.Location = New System.Drawing.Point(405, 433)
        Me.txtObservacionesVehiculo.Multiline = True
        Me.txtObservacionesVehiculo.Name = "txtObservacionesVehiculo"
        Me.txtObservacionesVehiculo.Size = New System.Drawing.Size(371, 78)
        Me.txtObservacionesVehiculo.TabIndex = 51
        '
        'txtSeguroVehiculo
        '
        Me.txtSeguroVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSeguroVehiculo.Location = New System.Drawing.Point(408, 367)
        Me.txtSeguroVehiculo.Multiline = True
        Me.txtSeguroVehiculo.Name = "txtSeguroVehiculo"
        Me.txtSeguroVehiculo.Size = New System.Drawing.Size(272, 22)
        Me.txtSeguroVehiculo.TabIndex = 50
        '
        'txtSerieVehiculo
        '
        Me.txtSerieVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSerieVehiculo.Location = New System.Drawing.Point(405, 304)
        Me.txtSerieVehiculo.Multiline = True
        Me.txtSerieVehiculo.Name = "txtSerieVehiculo"
        Me.txtSerieVehiculo.Size = New System.Drawing.Size(272, 22)
        Me.txtSerieVehiculo.TabIndex = 49
        '
        'txtAnioVehiculo
        '
        Me.txtAnioVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAnioVehiculo.Location = New System.Drawing.Point(406, 251)
        Me.txtAnioVehiculo.Multiline = True
        Me.txtAnioVehiculo.Name = "txtAnioVehiculo"
        Me.txtAnioVehiculo.Size = New System.Drawing.Size(272, 22)
        Me.txtAnioVehiculo.TabIndex = 48
        '
        'txtModeloVehiculo
        '
        Me.txtModeloVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtModeloVehiculo.Location = New System.Drawing.Point(409, 199)
        Me.txtModeloVehiculo.Multiline = True
        Me.txtModeloVehiculo.Name = "txtModeloVehiculo"
        Me.txtModeloVehiculo.Size = New System.Drawing.Size(272, 22)
        Me.txtModeloVehiculo.TabIndex = 47
        '
        'txtMotorVehiculo
        '
        Me.txtMotorVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMotorVehiculo.Location = New System.Drawing.Point(406, 142)
        Me.txtMotorVehiculo.Multiline = True
        Me.txtMotorVehiculo.Name = "txtMotorVehiculo"
        Me.txtMotorVehiculo.Size = New System.Drawing.Size(272, 22)
        Me.txtMotorVehiculo.TabIndex = 46
        '
        'txtPlacaVehiculo
        '
        Me.txtPlacaVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPlacaVehiculo.Location = New System.Drawing.Point(46, 444)
        Me.txtPlacaVehiculo.Multiline = True
        Me.txtPlacaVehiculo.Name = "txtPlacaVehiculo"
        Me.txtPlacaVehiculo.Size = New System.Drawing.Size(272, 22)
        Me.txtPlacaVehiculo.TabIndex = 45
        '
        'txtVerificacionVehiculo
        '
        Me.txtVerificacionVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVerificacionVehiculo.Location = New System.Drawing.Point(48, 378)
        Me.txtVerificacionVehiculo.Multiline = True
        Me.txtVerificacionVehiculo.Name = "txtVerificacionVehiculo"
        Me.txtVerificacionVehiculo.Size = New System.Drawing.Size(272, 22)
        Me.txtVerificacionVehiculo.TabIndex = 44
        '
        'txtCilindrajeVehiculo
        '
        Me.txtCilindrajeVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCilindrajeVehiculo.Location = New System.Drawing.Point(48, 315)
        Me.txtCilindrajeVehiculo.Multiline = True
        Me.txtCilindrajeVehiculo.Name = "txtCilindrajeVehiculo"
        Me.txtCilindrajeVehiculo.Size = New System.Drawing.Size(272, 22)
        Me.txtCilindrajeVehiculo.TabIndex = 43
        '
        'txtEntidadVehiculo
        '
        Me.txtEntidadVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEntidadVehiculo.Location = New System.Drawing.Point(49, 262)
        Me.txtEntidadVehiculo.Multiline = True
        Me.txtEntidadVehiculo.Name = "txtEntidadVehiculo"
        Me.txtEntidadVehiculo.Size = New System.Drawing.Size(272, 22)
        Me.txtEntidadVehiculo.TabIndex = 42
        '
        'txtMarcaVehiculo
        '
        Me.txtMarcaVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMarcaVehiculo.Location = New System.Drawing.Point(52, 210)
        Me.txtMarcaVehiculo.Multiline = True
        Me.txtMarcaVehiculo.Name = "txtMarcaVehiculo"
        Me.txtMarcaVehiculo.Size = New System.Drawing.Size(272, 22)
        Me.txtMarcaVehiculo.TabIndex = 41
        '
        'txtCodigoVehiculo
        '
        Me.txtCodigoVehiculo.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCodigoVehiculo.Location = New System.Drawing.Point(49, 153)
        Me.txtCodigoVehiculo.Multiline = True
        Me.txtCodigoVehiculo.Name = "txtCodigoVehiculo"
        Me.txtCodigoVehiculo.Size = New System.Drawing.Size(272, 22)
        Me.txtCodigoVehiculo.TabIndex = 40
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(401, 113)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(69, 23)
        Me.Label12.TabIndex = 39
        Me.Label12.Text = "Motor: "
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(400, 404)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(129, 23)
        Me.Label11.TabIndex = 38
        Me.Label11.Text = "Observaciones"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(402, 341)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(67, 23)
        Me.Label10.TabIndex = 37
        Me.Label10.Text = "Seguro"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(404, 282)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 23)
        Me.Label9.TabIndex = 36
        Me.Label9.Text = "Serie:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(407, 227)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 23)
        Me.Label8.TabIndex = 35
        Me.Label8.Text = "Año:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(404, 170)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 23)
        Me.Label7.TabIndex = 34
        Me.Label7.Text = "Modelo:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(44, 415)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 23)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "Placa"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(45, 352)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 23)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "Verificacion"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(47, 293)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(97, 23)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "Cilindraje: "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(49, 238)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(80, 23)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "Entidad:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(47, 181)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 23)
        Me.Label2.TabIndex = 29
        Me.Label2.Text = "Marca:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(44, 124)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(72, 23)
        Me.Label13.TabIndex = 28
        Me.Label13.Text = "Codigo:"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AgregarVehiculoToolStripMenuItem1, Me.ActualizarVehiculoToolStripMenuItem1, Me.EliminarVehiculoToolStripMenuItem1, Me.BuscarVehiculoToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(944, 27)
        Me.MenuStrip1.TabIndex = 32
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AgregarVehiculoToolStripMenuItem1
        '
        Me.AgregarVehiculoToolStripMenuItem1.Name = "AgregarVehiculoToolStripMenuItem1"
        Me.AgregarVehiculoToolStripMenuItem1.Size = New System.Drawing.Size(81, 23)
        Me.AgregarVehiculoToolStripMenuItem1.Text = "Agregar"
        '
        'ActualizarVehiculoToolStripMenuItem1
        '
        Me.ActualizarVehiculoToolStripMenuItem1.Name = "ActualizarVehiculoToolStripMenuItem1"
        Me.ActualizarVehiculoToolStripMenuItem1.Size = New System.Drawing.Size(95, 23)
        Me.ActualizarVehiculoToolStripMenuItem1.Text = "Actualizar"
        '
        'EliminarVehiculoToolStripMenuItem1
        '
        Me.EliminarVehiculoToolStripMenuItem1.Name = "EliminarVehiculoToolStripMenuItem1"
        Me.EliminarVehiculoToolStripMenuItem1.Size = New System.Drawing.Size(82, 23)
        Me.EliminarVehiculoToolStripMenuItem1.Text = "Eliminar"
        '
        'BuscarVehiculoToolStripMenuItem1
        '
        Me.BuscarVehiculoToolStripMenuItem1.Name = "BuscarVehiculoToolStripMenuItem1"
        Me.BuscarVehiculoToolStripMenuItem1.Size = New System.Drawing.Size(73, 23)
        Me.BuscarVehiculoToolStripMenuItem1.Text = "Buscar "
        '
        'btnSiguiente
        '
        Me.btnSiguiente.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnSiguiente.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSiguiente.Location = New System.Drawing.Point(651, 565)
        Me.btnSiguiente.Name = "btnSiguiente"
        Me.btnSiguiente.Size = New System.Drawing.Size(124, 35)
        Me.btnSiguiente.TabIndex = 35
        Me.btnSiguiente.Text = "Siguiente"
        Me.btnSiguiente.UseVisualStyleBackColor = False
        '
        'btnCancelar
        '
        Me.btnCancelar.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnCancelar.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelar.Location = New System.Drawing.Point(783, 565)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(124, 35)
        Me.btnCancelar.TabIndex = 36
        Me.btnCancelar.Text = "Cancelar"
        Me.btnCancelar.UseVisualStyleBackColor = False
        '
        'btnRegresar
        '
        Me.btnRegresar.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRegresar.Font = New System.Drawing.Font("Berlin Sans FB", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRegresar.Location = New System.Drawing.Point(46, 565)
        Me.btnRegresar.Name = "btnRegresar"
        Me.btnRegresar.Size = New System.Drawing.Size(124, 35)
        Me.btnRegresar.TabIndex = 37
        Me.btnRegresar.Text = "Regresar"
        Me.btnRegresar.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Berlin Sans FB", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(48, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 23)
        Me.Label1.TabIndex = 52
        Me.Label1.Text = "Cliente:"
        '
        'cmbClientes
        '
        Me.cmbClientes.FormattingEnabled = True
        Me.cmbClientes.Location = New System.Drawing.Point(47, 74)
        Me.cmbClientes.Name = "cmbClientes"
        Me.cmbClientes.Size = New System.Drawing.Size(269, 39)
        Me.cmbClientes.TabIndex = 53
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(944, 610)
        Me.Controls.Add(Me.btnRegresar)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnSiguiente)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form3"
        Me.Text = "  "
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtObservacionesVehiculo As TextBox
    Friend WithEvents txtSeguroVehiculo As TextBox
    Friend WithEvents txtSerieVehiculo As TextBox
    Friend WithEvents txtAnioVehiculo As TextBox
    Friend WithEvents txtModeloVehiculo As TextBox
    Friend WithEvents txtMotorVehiculo As TextBox
    Friend WithEvents txtPlacaVehiculo As TextBox
    Friend WithEvents txtVerificacionVehiculo As TextBox
    Friend WithEvents txtCilindrajeVehiculo As TextBox
    Friend WithEvents txtEntidadVehiculo As TextBox
    Friend WithEvents txtMarcaVehiculo As TextBox
    Friend WithEvents txtCodigoVehiculo As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents AgregarVehiculoToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ActualizarVehiculoToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents EliminarVehiculoToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents BuscarVehiculoToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents btnSiguiente As Button
    Friend WithEvents btnCancelar As Button
    Friend WithEvents btnRegresar As Button
    Friend WithEvents cmbClientes As ComboBox
    Friend WithEvents Label1 As Label
End Class
