﻿Public Class Form2
    Private clienteRepository As New ClienteRepository()

    Private Sub btnSiguiente_Click(sender As Object, e As EventArgs) Handles btnSiguiente.Click
        Dim form2 As New Form3()
        form2.Show()
        Me.Hide()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Configurar la apariencia inicial del formulario
        LimpiarControles()
    End Sub

    Private Sub LimpiarControles()
        ' Limpiar los valores de los controles del cliente
        txtClienteCodigo.Clear()
        txtNombreCompleto.Clear()
        txtDireccion.Clear()
        txtDireccion.Clear()
        txtCorreo.Clear()
        dtpFechaNacimiento.Value = DateTime.Today
    End Sub

    Private Sub AgregarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarClienteToolStripMenuItem1.Click
        ' Validar que los campos obligatorios no estén vacíos
        If String.IsNullOrWhiteSpace(txtNombreCompleto.Text) OrElse String.IsNullOrWhiteSpace(txtDireccion.Text) Then
            MessageBox.Show("Por favor, complete los campos obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Crear un nuevo cliente con los datos ingresados
        Dim nuevoCliente As New Cliente()
        nuevoCliente.NombreCompleto = txtNombreCompleto.Text
        nuevoCliente.Direccion = txtDireccion.Text
        nuevoCliente.Telefono = txtDireccion.Text
        nuevoCliente.CorreoElectronico = txtCorreo.Text
        nuevoCliente.FechaNacimiento = dtpFechaNacimiento.Value

        ' Agregar el nuevo cliente a la base de datos a través del ClienteRepository
        Try
            Dim codigoCliente As Integer = clienteRepository.AgregarCliente(nuevoCliente)

            ' Limpiar los controles después de agregar el cliente
            LimpiarControles()

            ' Mostrar mensaje de éxito
            MessageBox.Show("Cliente agregado correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show($"Error al agregar cliente: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ModificarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ActualizarClienteToolStripMenuItem1.Click
        ' Validar que se haya ingresado un código de cliente válido
        If String.IsNullOrWhiteSpace(txtClienteCodigo.Text) OrElse Not EsCodigoValido(txtClienteCodigo.Text) Then
            MessageBox.Show("Por favor, ingrese un código de cliente válido para modificar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Obtener el código de cliente a modificar
        Dim codigoCliente As Integer = Integer.Parse(txtClienteCodigo.Text)

        ' Buscar el cliente en la base de datos a través del ClienteRepository
        Dim clienteAModificar As Cliente = clienteRepository.BuscarClientePorCodigo(codigoCliente)

        If clienteAModificar Is Nothing Then
            MessageBox.Show("No se encontró un cliente con el código especificado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Actualizar los datos del cliente con los valores de los controles
        clienteAModificar.NombreCompleto = txtNombreCompleto.Text
        clienteAModificar.Direccion = txtDireccion.Text
        clienteAModificar.Telefono = txtDireccion.Text
        clienteAModificar.CorreoElectronico = txtCorreo.Text
        clienteAModificar.FechaNacimiento = dtpFechaNacimiento.Value

        ' Guardar los cambios en la base de datos a través del ClienteRepository
        Try
            clienteRepository.ModificarCliente(clienteAModificar)

            ' Limpiar los controles después de modificar el cliente
            LimpiarControles()

            ' Mostrar mensaje de éxito
            MessageBox.Show("Cliente modificado correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show($"Error al modificar cliente: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub EliminarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EliminarClienteToolStripMenuItem1.Click
        ' Validar que se haya ingresado un código de cliente válido
        If String.IsNullOrWhiteSpace(txtClienteCodigo.Text) OrElse Not EsCodigoValido(txtClienteCodigo.Text) Then
            MessageBox.Show("Por favor, ingrese un código de cliente válido para eliminar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Obtener el código de cliente a eliminar
        Dim codigoCliente As Integer = Integer.Parse(txtClienteCodigo.Text)

        ' Buscar el cliente en la base de datos a través del ClienteRepository
        Dim clienteAEliminar As Cliente = clienteRepository.BuscarClientePorCodigo(codigoCliente)

        If clienteAEliminar Is Nothing Then
            MessageBox.Show("No se encontró un cliente con el código especificado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Eliminar el cliente de la base de datos a través del ClienteRepository
        Try
            clienteRepository.EliminarCliente(codigoCliente)

            ' Limpiar los controles después de eliminar el cliente
            LimpiarControles()

            ' Mostrar mensaje de éxito
            MessageBox.Show("Cliente eliminado correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show($"Error al eliminar cliente: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BuscarClienteToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles BuscarClienteToolStripMenuItem1.Click
        ' Validar que se haya ingresado un código de cliente válido para buscar
        If String.IsNullOrWhiteSpace(txtClienteCodigo.Text) OrElse Not EsCodigoValido(txtClienteCodigo.Text) Then
            MessageBox.Show("Por favor, ingrese un código de cliente válido para buscar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Obtener el código de cliente a buscar
        Dim codigoCliente As Integer = Integer.Parse(txtClienteCodigo.Text)

        ' Buscar el cliente en la base de datos a través del ClienteRepository
        Dim clienteBuscado As Cliente = clienteRepository.BuscarClientePorCodigo(codigoCliente)

        If clienteBuscado Is Nothing Then
            MessageBox.Show("No se encontró un cliente con el código especificado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Mostrar los datos del cliente encontrado en los controles
        txtNombreCompleto.Text = clienteBuscado.NombreCompleto
        txtDireccion.Text = clienteBuscado.Direccion
        txtDireccion.Text = clienteBuscado.Telefono
        txtCorreo.Text = clienteBuscado.CorreoElectronico
        dtpFechaNacimiento.Value = clienteBuscado.FechaNacimiento
    End Sub

    Private Function EsCodigoValido(codigo As String) As Boolean
        ' Validar si el código ingresado es un número entero válido
        Dim resultado As Integer
        Return Integer.TryParse(codigo, resultado)
    End Function

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        End
    End Sub

    Private Sub btnRegresar_Click(sender As Object, e As EventArgs) Handles btnRegresar.Click
        Dim form1 As Form1 = Application.OpenForms.OfType(Of Form1)().FirstOrDefault()
        If form1 IsNot Nothing Then
            form1.Show()
            Me.Close()
        End If
    End Sub
End Class
